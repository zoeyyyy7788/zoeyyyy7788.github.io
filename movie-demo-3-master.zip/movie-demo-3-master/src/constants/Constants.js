export const API_KEY = 'api_key=fec8b5ab27b292a68294261bb21b04a5';
export const BASE_MOVIE_PATH = 'https://api.themoviedb.org/3/movie/';
export const SEARCH_MOVIE_PATH = 'https://api.themoviedb.org/3/search/movie';
export const BASE_URL_PATH = 'https://api.themoviedb.org/3/';
export const BASE_POSTER_PATH = 'https://image.tmdb.org/t/p';
export const BASE_BACKDROP_PATH = 'https://image.tmdb.org/t/p/original';
